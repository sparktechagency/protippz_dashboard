export const UpdatePasswordFields = [
    {
        name: 'old_Password',
        label: 'Current Password',
        placeholder: 'insert your password',
        required: true,
        message: 'please input your password',
        type: 'password',
    },
    {
        name: 'password',
        label: 'New Password',
        placeholder: 'insert your password',
        required: true,
        message: 'please input your password',
        type: 'password',
    },
    {
        name: 'confirm_password',
        label: 'Confirm New Password',
        placeholder: 'insert your Confirm password',
        required: true,
        message: 'please input your Confirm password',
        type: 'password',
    },
]