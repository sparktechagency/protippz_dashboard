export const ForgetPasswordFields = [
    {
        name: 'email',
        label: 'Email Address',
        placeholder: 'siyamoffice0273@gmail.com',
        required: true,
        message: 'please input your Email',
        type: 'email',
    },
]